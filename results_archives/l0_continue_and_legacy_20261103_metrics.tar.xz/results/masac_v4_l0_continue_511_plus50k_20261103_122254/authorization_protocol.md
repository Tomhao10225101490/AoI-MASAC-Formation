# V4 L0 PARALLEL continuation — seed 511 +50k

**Experiment id:** `l0_continue_511_plus50k_20261103`  
**Created:** 2026-11-03 12:21:30 Asia/Shanghai  
**Authorization:** User **B** (t0s9) + intensity demand **t1u** (2026-11-03).

## Why

Primary seed 533 continue holds the global L0 lock. This sibling resumes seed **511** from `checkpoint_050000` for +50k under a **per-arm lock**, registering in `masac_v4_parallel_runs.json` without touching `masac_v4_active_run.json`.

## Constraints

- Standard observation only; no Attention / maneuverability / L1
- Same frozen `configs/masac_v4/l0_protocol.json` for hash continuity
- `failure_action=save_and_diagnose`
- Gate ≥0.6 on 12 L0 maps for this seed

## Launch

```bash
caffeinate -dims ./.venv/bin/python scripts/train_masac_v4_l0_parallel_continue.py \
  --out results/masac_v4_l0_continue_511_plus50k_<timestamp> \
  --protocol configs/masac_v4/l0_protocol.json \
  --authorization-protocol configs/masac_v4/l0_continue_511_plus50k_20261103.json \
  --resume results/masac_v4_l0_legacy_50k_20261103_102637/standard_511/checkpoint_050000 \
  --extra-steps 50000
```
