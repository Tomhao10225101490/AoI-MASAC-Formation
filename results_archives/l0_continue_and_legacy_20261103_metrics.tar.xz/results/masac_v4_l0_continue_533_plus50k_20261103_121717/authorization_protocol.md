# V4 L0 continuation protocol — seed 533 +50k

**Experiment id:** `l0_continue_533_plus50k_20261103`  
**Created:** 2026-11-03 12:13:37 Asia/Shanghai  
**Authorization:** User Tom Zhong chose **B** (widget `t0s9`, 2026-11-03) after the L0 gate failed. This is an explicit new protocol, not a silent `failure_action` budget expand.

## Why this arm

Parent run `results/masac_v4_l0_legacy_50k_20261103_102637` finished gate **FAILED**:

| seed | final | gate (≥60%) |
|------|-------|-------------|
| 511 | 1/12 | fail |
| 522 | 1/12 | fail |
| 533 | 6/12 | fail (closest; first nonzero team successes; late 48k→50k jump) |

Diagnosis: `results/masac_v4_l0_legacy_50k_gate_diagnosis_20261103` — timeouts dominate; capture ball + speed simultaneous; maps reference-feasible.

**Primary (launch now when Mac is online):** resume seed **533** from `checkpoint_050000` for **+50k** steps (target total 100k), Standard observation only.

**Secondary (documented only):** fresh three-seed 100k Standard L0 under a new id — launch **only** if resume is impossible.

## Frozen constraints

- Same L0 development maps (830001–830012)
- Eval gate: ≥0.6 joint success on those 12 maps for seed 533 (≥8/12)
- `failure_action=save_and_diagnose` — no auto further budget
- Do **not** start Attention / maneuverability / Critic A/B / L1

## Expected checkpoint (verify on Mac before launch)

Likely path (first existing wins):

1. `results/masac_v4_l0_legacy_50k_20261103_102637/standard_533/checkpoint_050000`
2. `.../standard_533/checkpoints/checkpoint_050000`
3. `.../seed_533/checkpoint_050000`

## Train entry

- Base protocol: `configs/masac_v4/l0_protocol.json`
- Entry: `scripts/train_masac_v4_l0.py`
- Parent manifest already has a `resume_from` field (was `null`); prefer existing CLI/protocol resume rather than editing core algorithm code.

## Launch status at write time

**Training was NOT started.** TomMac-mini (`c70e463e-5629-4769-84af-f0ba33183f85`) was offline. Files staged under box `/workspace/masac-v4-continue-protocol/`.

## Runner mechanics (important)

Frozen `scripts/train_masac_v4_l0.py` hardcodes `steps=50000` in `validate_protocol` and resume compares source hashes. Resuming `checkpoint_050000` with the frozen runner would execute **0** new steps (`range(50001, 50001)`). Editing the frozen script would invalidate checkpoint source hashes.

Therefore continuation uses a **new** entrypoint that leaves the frozen runner byte-identical:

```bash
./.venv/bin/python scripts/train_masac_v4_l0_continue.py \
  --out results/masac_v4_l0_continue_533_plus50k_<timestamp> \
  --protocol configs/masac_v4/l0_protocol.json \
  --authorization-protocol configs/masac_v4/l0_continue_533_plus50k_20261103.json \
  --resume results/masac_v4_l0_legacy_50k_20261103_102637/standard_533/checkpoint_050000 \
  --extra-steps 50000
```

Target total steps = 50000 + 50000 = 100000 for seed 533 only. Gate still ≥0.6 on the 12 L0 maps. `failure_action=save_and_diagnose`.
